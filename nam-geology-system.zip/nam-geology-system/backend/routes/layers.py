from flask import Blueprint, jsonify
from config import (
    GEO_SERVER_URL, GEOLOGY_LAYER, MINERALS_LAYER,
    ROADS_LAYER, DISTRICTS_LAYER, TOWNS_VILLAGES_LAYER,
    REGIONS_LAYER, COUNTRY_LAYER
)

layers_bp = Blueprint("layers", __name__)

@layers_bp.route('/api/layers')
def get_layers():
    return jsonify([
        {"title": "1:1M Geology", "url": GEO_SERVER_URL, "layer": GEOLOGY_LAYER},
        {"title": "Mineral Occurrences", "url": GEO_SERVER_URL, "layer": MINERALS_LAYER},
        {"title": "Roads", "url": GEO_SERVER_URL, "layer": ROADS_LAYER},
        {"title": "Districts", "url": GEO_SERVER_URL, "layer": DISTRICTS_LAYER},
        {"title": "Towns & Villages", "url": GEO_SERVER_URL, "layer": TOWNS_VILLAGES_LAYER},
        {"title": "Regions", "url": GEO_SERVER_URL, "layer": REGIONS_LAYER},
        {"title": "Country Boundary", "url": GEO_SERVER_URL, "layer": COUNTRY_LAYER}
    ])
